# Import Template Text Export

Source of truth: `v1/src/App.tsx`  
Scope: all current import template payloads used by the UI

---

## Quick Import Templates

### support — Support Ticket

Description: Support template: triage incoming tickets, decide if issue category is known, resolve with knowledge base when possible, and escalate specialist cases before closure.

```text
Start: Customer submits ticket
Triage request
Decision: Is issue category identified?
Resolve with knowledge base
Escalate to specialist
End: Ticket closed
```

### onboarding — Customer Onboarding

Description: Onboarding template: capture setup requirements, provision account access, validate readiness, and complete enablement before go-live.

```text
Start: Customer signs agreement
Collect setup requirements
Provision account
Decision: Is setup validated?
Run enablement session
End: Customer live
```

### sales — Sales Opportunity

Description: Sales template: qualify lead potential, confirm prospect fit, run discovery, and progress to proposal through close.

```text
Start: Lead created
Qualify opportunity
Decision: Is prospect qualified?
Run discovery call
Prepare proposal
End: Opportunity closed
```

---

## Test Import Templates

### gold-toc-seed — Gold TOC Seed (mode: text)

```text
Cluster: Core Concepts & Account Management
Cluster: User Data & Support Issues
Cluster: Payments & Deposits
Cluster: Withdrawals & Cashier
Cluster: Verification & Risk
Cluster: Bonuses & Gamification
Cluster: Sports Betting
Cluster: Account Status & Safety
```

### wd-4-2-raw — 4.2 WD Raw (mode: ai)

```text
4.2 Processing a Withdrawal
Finance tab baseline: initiated withdrawal appears as Pending.
Statuses include Pending, Cancelled/Declined, Complete, and Awaiting (bug state requiring manual cancellation).
Cancellation paths: player self-cancel in Cashier while Pending; KYC cancellation for wrong details/verification failures; CS escalation to SM/support channel on request.
If first cancellation, advise resubmission with same method, Bank Transfer, or different method with minimum deposit + x1 wager.
If second/third cancellation, escalate to finance for manual KYC check and tell player to wait for email.
Processing SLA: finance handles within 3 business days, 10:00-18:00 (+2 GMT), excluding weekends.
Progression guidance: pending <=3 days (queue reassurance), pending >3 days (empathy + delay reassurance), complete 3-5 days (bank settlement notice), complete >5 days (request ARN via finance Slack).
ARN is provided to the player for bank tracking; agents cannot track it directly.
```

### wd-4-2-gold — 4.2 WD Gold (mode: text)

```text
Start: Player submits withdrawal request.
Check withdrawal status in Finance tab.
Decision: Is status Pending and under 3 business days?
Inform player withdrawal is in queue and within normal processing time.
Decision: Is status Pending longer than 3 business days?
Acknowledge delay, reassure funds are safe, and apologize.
Decision: Is status Complete and fewer than 5 business days since payout?
Inform player funds were sent and bank settlement may take 3-5 business days.
Decision: Is status Complete and more than 5 business days since payout?
Escalate to finance for ARN request and tell player update will come by email.
Decision: Is status Awaiting?
Cancel manually and ask player to submit withdrawal again.
Decision: Is cancellation requested while status is Pending?
Guide self-cancel in Cashier; if impossible escalate to SM/support channel.
End: Withdrawal case resolved or escalated.
```

### cb-6-3-raw — 6.3 CB Raw (mode: ai)

```text
6.3 Cashback Weekly / Live Casino Cashback
Cashback is a real-balance cash bonus based on percentage of losses and subject to 1x wagering.
Types include Weekly cashback and Daily cashback (special VIP offer).
Weekly Casino cashback is based on slot losses, credited Monday, minimum 5 EUR, VIP levels 3/4/5 only.
VIP percentages: Gold 5%, Platinum 10%, Diamond 15%.
Weekly Live Casino cashback is 25%, based on Live Casino losses only, credited Monday, minimum 5 EUR, available to all account levels.
Agents must confirm which cashback promo the player means and check logs for auto-credit.
Automated weekly cashback may be credited at 07:00 CY/BG time; on NR1 players activate from Bonuses section.
Agents can advise players to OPT-IN weekly; opting in any day still applies for following Monday.
```

### cb-6-3-gold — 6.3 CB Gold (mode: text)

```text
Start: Player contacts support to claim cashback.
Confirm which cashback promotion the player is referring to.
Decision: Is this Weekly Casino cashback?
Check slot losses from prior week and minimum 5 EUR threshold.
Decision: Is player VIP level 3, 4, or 5?
Apply cashback percentage by level (Gold 5%, Platinum 10%, Diamond 15%).
Decision: Is this Weekly Live Casino cashback?
Check live casino losses only and apply 25% cashback if minimum threshold is met.
Check logs for automated cashback credit at 07:00 CY/BG.
If auto-credited, guide player to activate bonus from bonuses section.
Advise player to OPT-IN for weekly cashback going forward.
End: Cashback request resolved and player informed.
```

### ar-8-1-raw — 8.1 AR Raw (mode: ai)

```text
8.1 Account Reopening
Players cannot reopen accounts themselves; requests come via chat/email and can be approved or denied.
Deny reasons include duplicate account, fraud, underage, GDPR, self-harm/complaints/care-listed.
Teams decide reopening path: casino escalates to support channel, sports escalates to sports channel.
Only SM can complete reopening for standard closure requests.
For denied requests, a mandatory log must state why denied.
After GA closure: ask responsible gambling confirmation question (T&C 4.1), escalate to SM, reopen after confirmation, send RG tools template.
If account is frozen after repeated failed logins, agent can reopen directly: status Open, reopen bonus program, save, leave log.
Offer password reset when player requests it.
```

### ar-8-1-gold — 8.1 AR Gold (mode: text)

```text
Start: Player requests account reopening via chat or email.
Check closure reason in account logs.
Decision: Is closure reason in deny list (duplicate, fraud, underage, GDPR, self-harm/care)?
Deny reopening request and log explicit denial reason.
Decision: Is player casino or sports?
Escalate casino to support channel; escalate sports to sports channel.
Decision: Is request after GA closure?
Ask T&C 4.1 responsible-gambling confirmation question.
Escalate to SM for reopen decision.
If approved, SM reopens account and agent sends RG tools template.
Decision: Is account frozen due to failed login attempts?
Reopen directly by setting status Open, reopening bonus program, saving changes, and leaving a log.
Offer password reset if needed.
End: Account reopened or denied with documented reason.
```

---

## Test Template Groups

- TOC: `gold-toc-seed`
- Withdrawal 4.2: `wd-4-2-raw`, `wd-4-2-gold`
- Cashback 6.3: `cb-6-3-raw`, `cb-6-3-gold`
- Reopening 8.1: `ar-8-1-raw`, `ar-8-1-gold`

---

## Additional UI Template Strings

### Blank template description

```text
Blank template: start from an empty map and describe your process goals, actors, and expected outcomes.
```

### AI placeholder

```text
Type draft text (notes or extract). Use → to generate, or top-right Import draft to apply adapters.
```

